<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Week 4 Assignment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            padding-top: 50px;
        }
        .checkmark {
            width: 100px;
            height: auto;
        }
    </style>
</head>
<body>
    <h1>Week 4 Assignment</h1>
    <img class="checkmark" src="green-checkmark.png" alt="Green Check Mark">
</body>
</html>
